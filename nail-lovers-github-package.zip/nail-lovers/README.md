# Nail Lovers by Tiana — new site + free CMS

Separate from your live site. Nothing here touches naillovers.netlify.app.

## 1. Images (already included)
Your uploaded photos are in `images/` (hero, tiana, gallery-1 to gallery-6). Replace any through the dashboard Gallery / Contact, Booking & SEO sections.

## 2. Publish (all free)
1. Create a new GitHub repo (e.g. nail-lovers-new) and upload all these files.
2. Netlify > Add new site > Import from GitHub (a NEW site, not your old one). Build settings are read from netlify.toml.
3. Edit `admin/config.yml`: set `repo:` to your GitHub repo, and `site_url` to the new Netlify address. Edit `content/settings.json` `site_url` too (or via dashboard).

## 3. Turn on the dashboard login
1. GitHub > Settings > Developer settings > OAuth Apps > New OAuth App.
   Homepage URL = your Netlify site URL. Callback URL = https://api.netlify.com/auth/done
2. Netlify > Site configuration > Access control > OAuth > Authentication Providers > Install provider > GitHub, paste Client ID and Secret.
3. Open https://YOUR-SITE.netlify.app/admin/ and log in with GitHub.

## What Tiana can edit at /admin/
Services and prices, promotions (with auto-expiry and an optional top banner), gallery photos, testimonials, contact details, booking options, hero and About text, and all SEO fields. Saving publishes automatically in about a minute.

## Getting booking and message emails (free)
Both forms are saved by Netlify Forms. In Netlify: Forms > Form notifications > Add notification > Email, choose "booking" and "contact" and enter Tiana's email. Booking also opens WhatsApp so the client can message her instantly. Forms only work on the deployed Netlify site, not in local preview.

## Quick preview
Open `OPEN-ME-PREVIEW.html` (one self-contained file, no other files needed). The full site for deployment is the rest of this folder.

## Local preview
`node build.js` then open dist/index.html through any static server.
