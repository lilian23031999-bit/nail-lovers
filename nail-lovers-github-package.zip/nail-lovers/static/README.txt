Put any file here that must sit at the root of the website, for example the
Google Search Console verification file (googleXXXXXXXX.html).
Everything in this folder is copied to the live site's main address when it is built.
